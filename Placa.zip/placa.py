import cv2
import imutils
import numpy as np
import pytesseract

# Configuração do caminho do Tesseract
pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files/Tesseract-OCR/tesseract.exe'

def preprocess_image(image_path):
    """
    Carrega e pré-processa a imagem.
    """
    img = cv2.imread(image_path, cv2.IMREAD_COLOR)
    img = cv2.resize(img, (600, 400))
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 11, 17, 17)
    return img, gray

def detect_edges(gray):
    """
    Detecta as bordas na imagem em tons de cinza.
    """
    return cv2.Canny(gray, 30, 200)

def find_plate_contour(edged, img):
    """
    Encontra o contorno da placa na imagem.
    """
    contours = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(contours)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:30]

    for c in contours:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(approx) == 4:
            x, y, w, h = cv2.boundingRect(c)
            aspect_ratio = w / float(h)
            if 2 <= aspect_ratio <= 6:  # Verifica a proporção típica de uma placa
                return approx, (x, y, w, h)
    
    return None, None

def extract_plate(img, gray, bounding_rect):
    """
    Extrai a região da placa da imagem.
    """
    x, y, w, h = bounding_rect
    return gray[y:y+h, x:x+w]

def recognize_text(cropped_image):
    """
    Reconhece o texto na imagem recortada da placa.
    """
    return pytesseract.image_to_string(cropped_image, config='--psm 8')

def main(image_path):
    img, gray = preprocess_image(image_path)
    edged = detect_edges(gray)
    
    # Exibir a imagem original e a imagem com bordas
    cv2.imshow('Gray', gray)
    cv2.imshow('Edged', edged)
    
    screenCnt, bounding_rect = find_plate_contour(edged, img)

    if screenCnt is None:
        print("No contour detected")
        return

    cv2.drawContours(img, [screenCnt], -1, (0, 0, 255), 3)
    cropped = extract_plate(img, gray, bounding_rect)
    text = recognize_text(cropped)

    print("Detected license plate number is:", text)

    # Exibição das imagens
    img = cv2.resize(img, (600, 400)) 
    cropped = cv2.resize(cropped, (400, 100))
    cv2.imshow('Car', img)
    cv2.imshow('Cropped', cropped)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    image_path = '06.jpg'
    main(image_path)
